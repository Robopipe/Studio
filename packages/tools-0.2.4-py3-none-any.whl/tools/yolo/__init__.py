from __future__ import annotations

import sys

sys.path.append("./yolo")
